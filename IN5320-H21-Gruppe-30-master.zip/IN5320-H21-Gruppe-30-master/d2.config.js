const config = {
    type: 'app',

    entryPoints: {
        app: './src/App.js',
    },
}

module.exports = config
