# IN5320 Project Submission - Group 30

## Functionality

- Dispensing Commodity
- Displaying Stock Balance of each commodity
- Displaying Transaction Log for each dispensed commodity
- Allows the user to specify how much of a commodity is typically needed

## Implementation

It is a simple user interface using navigation bar to the left and three modes:

- Stock Balance
- Dispense
- Dispense Registry

There is also a modal that appears when clicking each item in StockBalance, which lets you change the details of the commodity.

# Missing functionality/implementations, and things that do not work optimally. 

We wanted to highlight rows in Stockbalance that had a smaller endBalance than specified in the Modal.
We also haven't completed Se
rver Side Filtering or caching as they were deprioritized.